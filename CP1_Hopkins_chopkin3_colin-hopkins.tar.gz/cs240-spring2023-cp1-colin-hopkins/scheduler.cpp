#include <iostream>
#include <cstring> 
#include <vector>
#include <sstream>
#include <stdlib.h>
using namespace std;



  
int main()
{
    string str = "";
    string str3 = "";
    vector<string> array;

  
    cout << "Enter Command: \n";
    while (getline(cin, str)){
        stringstream str2(str);
        while(getline(str2, str3, ' ' )){
            array.push_back(str3);
        }
        if (array[0] == "quit"){
            break;
        }
        else if (array[0] == "build"){
        cout << array[0] << " course ";
        for (int i = 1; i < (int)array.size(); i++){
            cout << array[i] << " ";
        }
        cout << endl;
        }
        else if (array[0] == "cancel"){
        cout << array[0] << " course ";
        for (int i = 1; i < (int)array.size(); i++){
            cout << array[i] << " ";
        }
        cout << endl;
        }
        else if (array[0] == "enroll"){
        cout << array[0] << " student " << array[1] << " (" << array[2] << ") " << array[4] << ", " << array[3]; 
        cout << endl;
        }
        else if (array[0] == "add"){
        cout << array[0] << " student " << array[1] << " into course " << array[2];
        cout << endl;
        }
        else if (array[0] == "drop"){
        cout << "remove" << " student " << array[1] << " from course " << array[2];
        cout << endl;
        }
        else if (array[0] == "roster"){
        cout << array[0] << " of course " << array[1];
        cout << endl;
        }
        else if (array[0] == "schedule"){
        cout << array[0] << " of student " << array[1];
        cout << endl;
        }
        else{
            cout << "Command not recognized, please try again." << endl;
            
        }
        
        array.clear();
        


    }

        

    return 0;
}
